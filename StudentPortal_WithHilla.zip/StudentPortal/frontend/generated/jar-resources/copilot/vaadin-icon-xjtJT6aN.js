import { L as e, K as o } from "./copilot-5xZabcKF.js";
const a = {
  tagName: "vaadin-icon",
  displayName: "Icon",
  elements: [
    {
      selector: "vaadin-icon",
      displayName: "Icon",
      properties: [
        e.iconColor,
        e.iconSize,
        o.backgroundColor,
        o.borderColor,
        o.borderWidth,
        o.borderRadius
      ]
    }
  ]
};
export {
  a as default
};
