import { O as a, P as t } from "./copilot-5xZabcKF.js";
const e = {
  tagName: "vaadin-notification",
  displayName: "Notification",
  elements: [
    {
      selector: "vaadin-notification-card::part(overlay)",
      displayName: "Notification card",
      properties: a
    },
    {
      selector: "vaadin-notification-card::part(content)",
      displayName: "Content",
      properties: t
    }
  ]
};
export {
  e as default
};
