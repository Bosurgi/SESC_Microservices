import { O as a } from "./copilot-5xZabcKF.js";
const t = {
  tagName: "vaadin-details",
  displayName: "Details",
  elements: [
    {
      selector: "vaadin-details",
      displayName: "Root element",
      properties: a
    }
  ]
};
export {
  t as default
};
