export declare const icons: {
    crosshair: import("lit").TemplateResult<2>;
    square: import("lit").TemplateResult<2>;
    font: import("lit").TemplateResult<2>;
    undo: import("lit").TemplateResult<2>;
    redo: import("lit").TemplateResult<2>;
    cross: import("lit").TemplateResult<2>;
};
