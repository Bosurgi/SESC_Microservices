import { _getPropertyModel as _getPropertyModel_1, makeObjectEmptyValueCreator as makeObjectEmptyValueCreator_1, NumberModel as NumberModel_1, ObjectModel as ObjectModel_1, StringModel as StringModel_1 } from "@hilla/form";
import RoleModel_1 from "./RoleModel.js";
import StudentModel_1 from "./StudentModel.js";
import type User_1 from "./User.js";
class UserModel<T extends User_1 = User_1> extends ObjectModel_1<T> {
    static override createEmptyValue = makeObjectEmptyValueCreator_1(UserModel);
    get userId(): NumberModel_1 {
        return this[_getPropertyModel_1]("userId", (parent, key) => new NumberModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.Id" }], javaType: "java.lang.Long" } }));
    }
    get userName(): StringModel_1 {
        return this[_getPropertyModel_1]("userName", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get password(): StringModel_1 {
        return this[_getPropertyModel_1]("password", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get email(): StringModel_1 {
        return this[_getPropertyModel_1]("email", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get role(): RoleModel_1 {
        return this[_getPropertyModel_1]("role", (parent, key) => new RoleModel_1(parent, key, true));
    }
    get student(): StudentModel_1 {
        return this[_getPropertyModel_1]("student", (parent, key) => new StudentModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.OneToOne" }] } }));
    }
}
export default UserModel;
