import type Role_1 from "./Role.js";
import type Student_1 from "./Student.js";
interface User {
    userId?: number;
    userName?: string;
    password?: string;
    email?: string;
    role?: Role_1;
    student?: Student_1;
}
export default User;
