interface Module {
    moduleId?: number;
    title?: string;
    description?: string;
    fee?: number;
}
export default Module;
