import type Module_1 from "./Module.js";
import type Student_1 from "./Student.js";
interface Enrolments {
    enrolmentId?: number;
    student?: Student_1;
    module?: Module_1;
}
export default Enrolments;
