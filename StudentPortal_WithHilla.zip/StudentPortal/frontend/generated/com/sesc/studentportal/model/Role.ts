enum Role {
    STUDENT = "STUDENT",
    GUEST = "GUEST",
    ADMIN = "ADMIN"
}
export default Role;
