import { _getPropertyModel as _getPropertyModel_1, makeObjectEmptyValueCreator as makeObjectEmptyValueCreator_1, NumberModel as NumberModel_1, ObjectModel as ObjectModel_1 } from "@hilla/form";
import type Enrolments_1 from "./Enrolments.js";
import ModuleModel_1 from "./ModuleModel.js";
import StudentModel_1 from "./StudentModel.js";
class EnrolmentsModel<T extends Enrolments_1 = Enrolments_1> extends ObjectModel_1<T> {
    static override createEmptyValue = makeObjectEmptyValueCreator_1(EnrolmentsModel);
    get enrolmentId(): NumberModel_1 {
        return this[_getPropertyModel_1]("enrolmentId", (parent, key) => new NumberModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.Id" }], javaType: "java.lang.Long" } }));
    }
    get student(): StudentModel_1 {
        return this[_getPropertyModel_1]("student", (parent, key) => new StudentModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.ManyToOne" }] } }));
    }
    get module(): ModuleModel_1 {
        return this[_getPropertyModel_1]("module", (parent, key) => new ModuleModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.ManyToOne" }] } }));
    }
}
export default EnrolmentsModel;
