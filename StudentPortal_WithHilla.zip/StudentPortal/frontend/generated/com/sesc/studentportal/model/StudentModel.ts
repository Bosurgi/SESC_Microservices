import { _getPropertyModel as _getPropertyModel_1, ArrayModel as ArrayModel_1, BooleanModel as BooleanModel_1, makeObjectEmptyValueCreator as makeObjectEmptyValueCreator_1, NotBlank as NotBlank_1, NumberModel as NumberModel_1, ObjectModel as ObjectModel_1, StringModel as StringModel_1 } from "@hilla/form";
import EnrolmentsModel_1 from "./EnrolmentsModel.js";
import type Student_1 from "./Student.js";
import UserModel_1 from "./UserModel.js";
class StudentModel<T extends Student_1 = Student_1> extends ObjectModel_1<T> {
    static override createEmptyValue = makeObjectEmptyValueCreator_1(StudentModel);
    get studentId(): NumberModel_1 {
        return this[_getPropertyModel_1]("studentId", (parent, key) => new NumberModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.Id" }], javaType: "java.lang.Long" } }));
    }
    get studentNumber(): StringModel_1 {
        return this[_getPropertyModel_1]("studentNumber", (parent, key) => new StringModel_1(parent, key, true, { validators: [new NotBlank_1()], meta: { javaType: "java.lang.String" } }));
    }
    get surname(): StringModel_1 {
        return this[_getPropertyModel_1]("surname", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get firstName(): StringModel_1 {
        return this[_getPropertyModel_1]("firstName", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get isEnrolled(): BooleanModel_1 {
        return this[_getPropertyModel_1]("isEnrolled", (parent, key) => new BooleanModel_1(parent, key, true, { meta: { javaType: "java.lang.Boolean" } }));
    }
    get enrolments(): ArrayModel_1<EnrolmentsModel_1> {
        return this[_getPropertyModel_1]("enrolments", (parent, key) => new ArrayModel_1(parent, key, true, (parent, key) => new EnrolmentsModel_1(parent, key, true), { meta: { annotations: [{ name: "jakarta.persistence.OneToMany" }], javaType: "java.util.List" } }));
    }
    get user(): UserModel_1 {
        return this[_getPropertyModel_1]("user", (parent, key) => new UserModel_1(parent, key, true, { meta: { annotations: [{ name: "jakarta.persistence.OneToOne" }] } }));
    }
}
export default StudentModel;
