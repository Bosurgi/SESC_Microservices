import type Enrolments_1 from "./Enrolments.js";
import type User_1 from "./User.js";
interface Student {
    studentId?: number;
    studentNumber?: string;
    surname?: string;
    firstName?: string;
    isEnrolled?: boolean;
    enrolments?: Array<Enrolments_1 | undefined>;
    user?: User_1;
}
export default Student;
