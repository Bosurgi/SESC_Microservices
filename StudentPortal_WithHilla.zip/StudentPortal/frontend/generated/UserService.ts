import { EndpointRequestInit as EndpointRequestInit_1 } from "@hilla/frontend";
import type Student_1 from "./com/sesc/studentportal/model/Student.js";
import type User_1 from "./com/sesc/studentportal/model/User.js";
import client_1 from "./connect-client.default.js";
async function createUser_1(user: User_1, init?: EndpointRequestInit_1): Promise<User_1> { return client_1.call("UserService", "createUser", { user }, init); }
async function deleteUser_1(id: number, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("UserService", "deleteUser", { id }, init); }
async function findStudentFromUser_1(user: User_1, init?: EndpointRequestInit_1): Promise<Student_1> { return client_1.call("UserService", "findStudentFromUser", { user }, init); }
async function getAllUsers_1(init?: EndpointRequestInit_1): Promise<Array<User_1>> { return client_1.call("UserService", "getAllUsers", {}, init); }
async function getUserById_1(id: number, init?: EndpointRequestInit_1): Promise<User_1> { return client_1.call("UserService", "getUserById", { id }, init); }
async function getUserByUsername_1(username: string, init?: EndpointRequestInit_1): Promise<User_1> { return client_1.call("UserService", "getUserByUsername", { username }, init); }
async function updateUser_1(id: number, user: User_1, init?: EndpointRequestInit_1): Promise<User_1> { return client_1.call("UserService", "updateUser", { id, user }, init); }
export { createUser_1 as createUser, deleteUser_1 as deleteUser, findStudentFromUser_1 as findStudentFromUser, getAllUsers_1 as getAllUsers, getUserById_1 as getUserById, getUserByUsername_1 as getUserByUsername, updateUser_1 as updateUser };
