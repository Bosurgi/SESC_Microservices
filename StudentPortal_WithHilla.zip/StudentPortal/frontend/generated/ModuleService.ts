import { EndpointRequestInit as EndpointRequestInit_1 } from "@hilla/frontend";
import type Module_1 from "./com/sesc/studentportal/model/Module.js";
import client_1 from "./connect-client.default.js";
async function getAllModules_1(init?: EndpointRequestInit_1): Promise<Array<Module_1>> { return client_1.call("ModuleService", "getAllModules", {}, init); }
async function searchModules_1(keyword: string, init?: EndpointRequestInit_1): Promise<Array<Module_1>> { return client_1.call("ModuleService", "searchModules", { keyword }, init); }
export { getAllModules_1 as getAllModules, searchModules_1 as searchModules };
