// When this file is imported, global styles are automatically applied

import 'themes/my-hilla-app/styles.css';

