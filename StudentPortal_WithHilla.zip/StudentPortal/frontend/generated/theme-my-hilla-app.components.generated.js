


if (!document['_vaadintheme_my-hilla-app_componentCss']) {
  
  document['_vaadintheme_my-hilla-app_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

