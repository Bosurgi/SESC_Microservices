import {applyTheme as _applyTheme} from './theme-my-hilla-app.generated.js';
export const applyTheme = _applyTheme;
