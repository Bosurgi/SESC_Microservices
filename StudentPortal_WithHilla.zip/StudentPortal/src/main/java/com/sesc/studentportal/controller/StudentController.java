package com.sesc.studentportal.controller;

import org.springframework.web.bind.annotation.RestController;

/***
 * Controller for the Student entity.
 */
@RestController
public class StudentController {
    // TODO: Implement the StudentController
}
