package com.sesc.studentportal.model;

/***
 * Enum for the role of a user
 */
public enum Role {
    STUDENT,
    GUEST,
    ADMIN,
}
